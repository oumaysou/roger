VBoxManage controlvm debian poweroff soft
