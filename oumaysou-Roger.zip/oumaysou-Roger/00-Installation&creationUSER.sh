sudo apt-get install -y vim sudo mailutils unzip apache2 iptables-persistent netfilter-persistent
sudo usermod -aG sudo oumaysou