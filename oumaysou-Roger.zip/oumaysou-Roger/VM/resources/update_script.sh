echo "<==================UPDATE_SCRIPT=====================>"
echo -n "~Execution at "
date +%x_%H:%M:%S:%N 
apt-get update && apt-get upgrade

