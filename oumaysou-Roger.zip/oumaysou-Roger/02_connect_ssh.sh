#!/bin/bash
ssh -p 5432 oumaysou@10.12.33.1
